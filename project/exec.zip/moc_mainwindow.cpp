/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../project/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[31];
    char stringdata0[755];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 34), // "on_horizontalSlider_2_valueCh..."
QT_MOC_LITERAL(2, 46, 0), // ""
QT_MOC_LITERAL(3, 47, 5), // "value"
QT_MOC_LITERAL(4, 53, 22), // "on_radioButton_clicked"
QT_MOC_LITERAL(5, 76, 24), // "on_radioButton_2_clicked"
QT_MOC_LITERAL(6, 101, 24), // "on_radioButton_3_clicked"
QT_MOC_LITERAL(7, 126, 24), // "on_radioButton_4_clicked"
QT_MOC_LITERAL(8, 151, 26), // "on_tabWidget_tabBarClicked"
QT_MOC_LITERAL(9, 178, 5), // "index"
QT_MOC_LITERAL(10, 184, 27), // "on_tabWidget_currentChanged"
QT_MOC_LITERAL(11, 212, 24), // "on_radioButton_6_clicked"
QT_MOC_LITERAL(12, 237, 24), // "on_radioButton_5_clicked"
QT_MOC_LITERAL(13, 262, 24), // "on_radioButton_8_clicked"
QT_MOC_LITERAL(14, 287, 24), // "on_radioButton_7_clicked"
QT_MOC_LITERAL(15, 312, 28), // "on_learning_rate_sliderMoved"
QT_MOC_LITERAL(16, 341, 8), // "position"
QT_MOC_LITERAL(17, 350, 29), // "on_learning_rate_valueChanged"
QT_MOC_LITERAL(18, 380, 34), // "on_horizontalSlider_4_valueCh..."
QT_MOC_LITERAL(19, 415, 34), // "on_horizontalSlider_3_valueCh..."
QT_MOC_LITERAL(20, 450, 34), // "on_horizontalSlider_6_valueCh..."
QT_MOC_LITERAL(21, 485, 34), // "on_horizontalSlider_5_valueCh..."
QT_MOC_LITERAL(22, 520, 23), // "on_actionOpen_triggered"
QT_MOC_LITERAL(23, 544, 31), // "on_actionOpen_cascade_triggered"
QT_MOC_LITERAL(24, 576, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(25, 601, 24), // "on_action_Exit_triggered"
QT_MOC_LITERAL(26, 626, 34), // "on_actionNew_output_file_trig..."
QT_MOC_LITERAL(27, 661, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(28, 683, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(29, 707, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(30, 731, 23) // "on_pushButton_4_clicked"

    },
    "MainWindow\0on_horizontalSlider_2_valueChanged\0"
    "\0value\0on_radioButton_clicked\0"
    "on_radioButton_2_clicked\0"
    "on_radioButton_3_clicked\0"
    "on_radioButton_4_clicked\0"
    "on_tabWidget_tabBarClicked\0index\0"
    "on_tabWidget_currentChanged\0"
    "on_radioButton_6_clicked\0"
    "on_radioButton_5_clicked\0"
    "on_radioButton_8_clicked\0"
    "on_radioButton_7_clicked\0"
    "on_learning_rate_sliderMoved\0position\0"
    "on_learning_rate_valueChanged\0"
    "on_horizontalSlider_4_valueChanged\0"
    "on_horizontalSlider_3_valueChanged\0"
    "on_horizontalSlider_6_valueChanged\0"
    "on_horizontalSlider_5_valueChanged\0"
    "on_actionOpen_triggered\0"
    "on_actionOpen_cascade_triggered\0"
    "on_actionAbout_triggered\0"
    "on_action_Exit_triggered\0"
    "on_actionNew_output_file_triggered\0"
    "on_pushButton_clicked\0on_pushButton_2_clicked\0"
    "on_pushButton_3_clicked\0on_pushButton_4_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  144,    2, 0x08 /* Private */,
       4,    0,  147,    2, 0x08 /* Private */,
       5,    0,  148,    2, 0x08 /* Private */,
       6,    0,  149,    2, 0x08 /* Private */,
       7,    0,  150,    2, 0x08 /* Private */,
       8,    1,  151,    2, 0x08 /* Private */,
      10,    1,  154,    2, 0x08 /* Private */,
      11,    0,  157,    2, 0x08 /* Private */,
      12,    0,  158,    2, 0x08 /* Private */,
      13,    0,  159,    2, 0x08 /* Private */,
      14,    0,  160,    2, 0x08 /* Private */,
      15,    1,  161,    2, 0x08 /* Private */,
      17,    1,  164,    2, 0x08 /* Private */,
      18,    1,  167,    2, 0x08 /* Private */,
      19,    1,  170,    2, 0x08 /* Private */,
      20,    1,  173,    2, 0x08 /* Private */,
      21,    1,  176,    2, 0x08 /* Private */,
      22,    0,  179,    2, 0x08 /* Private */,
      23,    0,  180,    2, 0x08 /* Private */,
      24,    0,  181,    2, 0x08 /* Private */,
      25,    0,  182,    2, 0x08 /* Private */,
      26,    0,  183,    2, 0x08 /* Private */,
      27,    0,  184,    2, 0x08 /* Private */,
      28,    0,  185,    2, 0x08 /* Private */,
      29,    0,  186,    2, 0x08 /* Private */,
      30,    0,  187,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void, QMetaType::Int,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_horizontalSlider_2_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->on_radioButton_clicked(); break;
        case 2: _t->on_radioButton_2_clicked(); break;
        case 3: _t->on_radioButton_3_clicked(); break;
        case 4: _t->on_radioButton_4_clicked(); break;
        case 5: _t->on_tabWidget_tabBarClicked((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_tabWidget_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_radioButton_6_clicked(); break;
        case 8: _t->on_radioButton_5_clicked(); break;
        case 9: _t->on_radioButton_8_clicked(); break;
        case 10: _t->on_radioButton_7_clicked(); break;
        case 11: _t->on_learning_rate_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_learning_rate_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_horizontalSlider_4_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_horizontalSlider_3_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_horizontalSlider_6_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_horizontalSlider_5_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->on_actionOpen_triggered(); break;
        case 18: _t->on_actionOpen_cascade_triggered(); break;
        case 19: _t->on_actionAbout_triggered(); break;
        case 20: _t->on_action_Exit_triggered(); break;
        case 21: _t->on_actionNew_output_file_triggered(); break;
        case 22: _t->on_pushButton_clicked(); break;
        case 23: _t->on_pushButton_2_clicked(); break;
        case 24: _t->on_pushButton_3_clicked(); break;
        case 25: _t->on_pushButton_4_clicked(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 26;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
