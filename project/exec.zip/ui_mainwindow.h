/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.8.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionOpen;
    QAction *actionAbout;
    QAction *actionAbout_2;
    QAction *actionOpen_cascade;
    QAction *action_Exit;
    QAction *actionNew_output_file;
    QWidget *centralWidget;
    QTabWidget *tabWidget;
    QWidget *tab;
    QDialogButtonBox *buttonBox;
    QLabel *label_2;
    QLabel *label_3;
    QSlider *learning_rate;
    QSlider *horizontalSlider_2;
    QGroupBox *groupBox_3;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_7;
    QGroupBox *groupBox_4;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QWidget *tab_2;
    QSlider *horizontalSlider_4;
    QLabel *label_6;
    QDialogButtonBox *buttonBox_2;
    QLabel *label_4;
    QSlider *horizontalSlider_3;
    QLabel *label_7;
    QLabel *label_8;
    QSlider *horizontalSlider_5;
    QSlider *horizontalSlider_6;
    QGroupBox *groupBox;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_5;
    QGroupBox *groupBox_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QPushButton *pushButton;
    QPushButton *pushButton_4;
    QFrame *iWidget;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;
    QMenuBar *menuBar;
    QMenu *menuPedestrian_Detector;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(338, 473);
        actionOpen = new QAction(MainWindow);
        actionOpen->setObjectName(QStringLiteral("actionOpen"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionAbout_2 = new QAction(MainWindow);
        actionAbout_2->setObjectName(QStringLiteral("actionAbout_2"));
        actionOpen_cascade = new QAction(MainWindow);
        actionOpen_cascade->setObjectName(QStringLiteral("actionOpen_cascade"));
        action_Exit = new QAction(MainWindow);
        action_Exit->setObjectName(QStringLiteral("action_Exit"));
        actionNew_output_file = new QAction(MainWindow);
        actionNew_output_file->setObjectName(QStringLiteral("actionNew_output_file"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        tabWidget = new QTabWidget(centralWidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 0, 331, 461));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        buttonBox = new QDialogButtonBox(tab);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(150, 370, 166, 25));
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_2 = new QLabel(tab);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(10, 160, 121, 17));
        label_3 = new QLabel(tab);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(10, 220, 91, 17));
        learning_rate = new QSlider(tab);
        learning_rate->setObjectName(QStringLiteral("learning_rate"));
        learning_rate->setGeometry(QRect(10, 190, 271, 16));
        learning_rate->setMinimum(0);
        learning_rate->setMaximum(99);
        learning_rate->setSingleStep(1);
        learning_rate->setValue(20);
        learning_rate->setOrientation(Qt::Horizontal);
        horizontalSlider_2 = new QSlider(tab);
        horizontalSlider_2->setObjectName(QStringLiteral("horizontalSlider_2"));
        horizontalSlider_2->setGeometry(QRect(10, 250, 271, 16));
        horizontalSlider_2->setMaximum(1000);
        horizontalSlider_2->setValue(350);
        horizontalSlider_2->setOrientation(Qt::Horizontal);
        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(10, 10, 201, 61));
        radioButton_8 = new QRadioButton(groupBox_3);
        radioButton_8->setObjectName(QStringLiteral("radioButton_8"));
        radioButton_8->setGeometry(QRect(10, 30, 106, 23));
        radioButton_7 = new QRadioButton(groupBox_3);
        radioButton_7->setObjectName(QStringLiteral("radioButton_7"));
        radioButton_7->setGeometry(QRect(100, 30, 106, 23));
        radioButton_7->setChecked(true);
        groupBox_4 = new QGroupBox(tab);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 80, 201, 61));
        radioButton = new QRadioButton(groupBox_4);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(10, 30, 106, 23));
        radioButton_2 = new QRadioButton(groupBox_4);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(100, 30, 106, 23));
        radioButton_2->setChecked(true);
        pushButton_2 = new QPushButton(tab);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(220, 40, 83, 25));
        pushButton_3 = new QPushButton(tab);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(220, 110, 83, 25));
        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        horizontalSlider_4 = new QSlider(tab_2);
        horizontalSlider_4->setObjectName(QStringLiteral("horizontalSlider_4"));
        horizontalSlider_4->setGeometry(QRect(10, 180, 271, 16));
        horizontalSlider_4->setMaximum(100);
        horizontalSlider_4->setValue(11);
        horizontalSlider_4->setOrientation(Qt::Horizontal);
        label_6 = new QLabel(tab_2);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(10, 200, 91, 17));
        buttonBox_2 = new QDialogButtonBox(tab_2);
        buttonBox_2->setObjectName(QStringLiteral("buttonBox_2"));
        buttonBox_2->setGeometry(QRect(140, 390, 166, 25));
        buttonBox_2->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        label_4 = new QLabel(tab_2);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(10, 150, 121, 17));
        horizontalSlider_3 = new QSlider(tab_2);
        horizontalSlider_3->setObjectName(QStringLiteral("horizontalSlider_3"));
        horizontalSlider_3->setGeometry(QRect(10, 230, 271, 16));
        horizontalSlider_3->setMaximum(10);
        horizontalSlider_3->setValue(3);
        horizontalSlider_3->setOrientation(Qt::Horizontal);
        label_7 = new QLabel(tab_2);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(10, 320, 91, 17));
        label_8 = new QLabel(tab_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(10, 260, 121, 17));
        horizontalSlider_5 = new QSlider(tab_2);
        horizontalSlider_5->setObjectName(QStringLiteral("horizontalSlider_5"));
        horizontalSlider_5->setGeometry(QRect(10, 350, 271, 16));
        horizontalSlider_5->setMaximum(100);
        horizontalSlider_5->setValue(80);
        horizontalSlider_5->setOrientation(Qt::Horizontal);
        horizontalSlider_6 = new QSlider(tab_2);
        horizontalSlider_6->setObjectName(QStringLiteral("horizontalSlider_6"));
        horizontalSlider_6->setGeometry(QRect(10, 290, 271, 16));
        horizontalSlider_6->setMaximum(100);
        horizontalSlider_6->setValue(10);
        horizontalSlider_6->setOrientation(Qt::Horizontal);
        groupBox = new QGroupBox(tab_2);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 10, 201, 61));
        radioButton_6 = new QRadioButton(groupBox);
        radioButton_6->setObjectName(QStringLiteral("radioButton_6"));
        radioButton_6->setGeometry(QRect(10, 30, 106, 23));
        radioButton_5 = new QRadioButton(groupBox);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));
        radioButton_5->setGeometry(QRect(100, 30, 106, 23));
        radioButton_5->setChecked(true);
        groupBox_2 = new QGroupBox(tab_2);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(10, 80, 201, 61));
        radioButton_3 = new QRadioButton(groupBox_2);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));
        radioButton_3->setGeometry(QRect(10, 30, 106, 23));
        radioButton_4 = new QRadioButton(groupBox_2);
        radioButton_4->setObjectName(QStringLiteral("radioButton_4"));
        radioButton_4->setGeometry(QRect(100, 30, 106, 23));
        radioButton_4->setChecked(true);
        pushButton = new QPushButton(tab_2);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(220, 40, 83, 25));
        pushButton_4 = new QPushButton(tab_2);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(220, 110, 83, 25));
        tabWidget->addTab(tab_2, QString());
        iWidget = new QFrame(centralWidget);
        iWidget->setObjectName(QStringLiteral("iWidget"));
        iWidget->setGeometry(QRect(330, 0, 16, 421));
        MainWindow->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 338, 22));
        menuPedestrian_Detector = new QMenu(menuBar);
        menuPedestrian_Detector->setObjectName(QStringLiteral("menuPedestrian_Detector"));
        MainWindow->setMenuBar(menuBar);

        mainToolBar->addAction(actionOpen);
        mainToolBar->addAction(actionOpen_cascade);
        menuBar->addAction(menuPedestrian_Detector->menuAction());
        menuPedestrian_Detector->addAction(actionOpen);
        menuPedestrian_Detector->addAction(actionOpen_cascade);
        menuPedestrian_Detector->addAction(actionAbout);
        menuPedestrian_Detector->addAction(action_Exit);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Pedestrian counter", Q_NULLPTR));
        actionOpen->setText(QApplication::translate("MainWindow", "Open &video", Q_NULLPTR));
        actionOpen->setShortcut(QApplication::translate("MainWindow", "Alt+V", Q_NULLPTR));
        actionAbout->setText(QApplication::translate("MainWindow", "Instruction", Q_NULLPTR));
        actionAbout_2->setText(QApplication::translate("MainWindow", "&About", Q_NULLPTR));
        actionOpen_cascade->setText(QApplication::translate("MainWindow", "Open &cascade", Q_NULLPTR));
        actionOpen_cascade->setShortcut(QApplication::translate("MainWindow", "Alt+C", Q_NULLPTR));
        action_Exit->setText(QApplication::translate("MainWindow", "&Exit", Q_NULLPTR));
        action_Exit->setShortcut(QApplication::translate("MainWindow", "Alt+Q", Q_NULLPTR));
        actionNew_output_file->setText(QApplication::translate("MainWindow", "&New output file", Q_NULLPTR));
        actionNew_output_file->setShortcut(QApplication::translate("MainWindow", "Alt+N", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "Learning rate:", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Area size:", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Input mode:", Q_NULLPTR));
        radioButton_8->setText(QApplication::translate("MainWindow", "Camera", Q_NULLPTR));
        radioButton_7->setText(QApplication::translate("MainWindow", "&Video", Q_NULLPTR));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Detector mode:", Q_NULLPTR));
        radioButton->setText(QApplication::translate("MainWindow", "Vertical", Q_NULLPTR));
        radioButton_2->setText(QApplication::translate("MainWindow", "Hori&zontal", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "&Pause", Q_NULLPTR));
        pushButton_2->setShortcut(QApplication::translate("MainWindow", "Alt+P", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "&Debug", Q_NULLPTR));
        pushButton_3->setShortcut(QApplication::translate("MainWindow", "Alt+D", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "Movement detection", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "Min neighbors:", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Scale:", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "Max size:", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Min size:", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "Input mode:", Q_NULLPTR));
        radioButton_6->setText(QApplication::translate("MainWindow", "Camera", Q_NULLPTR));
        radioButton_5->setText(QApplication::translate("MainWindow", "&Video", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Detector mode:", Q_NULLPTR));
        radioButton_3->setText(QApplication::translate("MainWindow", "Vertical", Q_NULLPTR));
        radioButton_4->setText(QApplication::translate("MainWindow", "Hori&zontal", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "&Pause", Q_NULLPTR));
        pushButton->setShortcut(QApplication::translate("MainWindow", "Alt+P", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "&Debug", Q_NULLPTR));
        pushButton_4->setShortcut(QApplication::translate("MainWindow", "Alt+D", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "Recognition (haar)", Q_NULLPTR));
#ifndef QT_NO_ACCESSIBILITY
        iWidget->setAccessibleName(QApplication::translate("MainWindow", "frame", Q_NULLPTR));
#endif // QT_NO_ACCESSIBILITY
        menuPedestrian_Detector->setTitle(QApplication::translate("MainWindow", "&Menu", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
